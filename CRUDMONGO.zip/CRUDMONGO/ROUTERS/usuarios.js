const express=require('express');
const router=express.Router();
const Usuario=require('../MODELS/usuario');
//CREACION DEL INDEX O MODELO A UTILIZAR
router.get('/',async(req,res)=>{
    const usuarios=await Usuario.find();
    res.json(usuarios)
});
//CREACION DE USUARIO
router.post('/',async(req,res)=>{
    try {
        const usuario=new Usuario(req.body);
        await usuario.save();
        res.status(201).json(usuario);
    } catch (error) {
        res.status(400).json({mensaje:error.messaje});
    }
});
module.exports=router;