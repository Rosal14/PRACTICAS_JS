const mongoose=require('mongoose');
const conectarbd=async()=>{
    try {
        await mongoose.connect('mongodb://127.0.0.1:/crud_node');
        console.log('Conexion exitosa');
    } catch (error) {
        console.error('Error de conexion',ERROR);
        process.exit(1);
    }
};
module.exports=conectarbd;
