const mongoose=require('mongoose');
const UsuarioSchema=mongoose.Schema({
    nombre:{
        type:String,
        require:true
    },
    correo:{
        type:String,
        require:true,
        unique:true
    },
    edad:{
        type:Number
    },
    fecharegistro:{
        type:Date,
        default:Date.now
    }
});
module.exports=mongoose.model('usuario',UsuarioSchema);