const express=require('express');
const conectarbd=require('./CONFIG/db');
const cors=require('cors');
const app=express();
conectarbd();
app.use(cors());
app.use(express.json());
app.use('/api/usuarios',require('./ROUTERS/usuarios'));
const puerto=3000;
app.listen(puerto,()=>{
    console.log('Servidor corriendo en http://localhost:${puerto}');
});

